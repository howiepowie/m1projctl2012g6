rm *.dot
