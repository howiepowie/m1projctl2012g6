package preuve;

public class Couleur {

	public String valeur;

	public String toString() {
		return valeur;
	}

}
